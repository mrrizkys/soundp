<div id="regis-login-close">
X
</div>
<div id="user-upload-content-wrapper">