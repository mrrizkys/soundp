<div id="regis-login-close">
X
</div>
<div id="regis-login-content-wrapper">